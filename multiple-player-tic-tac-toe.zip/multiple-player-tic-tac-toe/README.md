# Multiple player  Tic-Tac-Toe 

A Pen created on CodePen.io. Original URL: [https://codepen.io/KRISHNA-PRAKASH-ROY/pen/GRzgExR](https://codepen.io/KRISHNA-PRAKASH-ROY/pen/GRzgExR).

